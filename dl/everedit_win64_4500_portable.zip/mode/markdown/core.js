var App = window.external;
var old_id = -1;
var old_dirty_id = -1;
var el_content = document.getElementById('content');
var highlight_code = true;
var old_doc = null;

function getFilePath(href) {
	if (href.match('^http.*')) {
		return href + 'http';
	} else if (href.match('^[c-zC-Z]:.*')) {
		return href + 'c';
	} else {
		if (href.match('^\\.[/\\\\]')) {
			href = href.substring(2);
		}

		var doc = App.ActiveDoc;
		var path = doc.PathName;
		var idx = 0;
		for (idx = path.length - 1; idx >= 0; idx--) {
			if (path.charAt(idx) == '/' || path.charAt(idx) == '\\') {
				break;
			}
		}
		return path.substring(0, idx + 1) + href;
	}
}

function InitMarked() {
	var renderer = new Markdown.marked.Renderer();
	renderer.listitem = function (text) {
		if (/^ *\[[xX ]\]\s*/.test(text)) {
			text = text
				.replace(/^\s*\[ \] */, '<input type="checkbox" disabled> ')
				.replace(/^\s*\[[xX]\] */, '<input type="checkbox" checked disabled> ');
			return '<li style="list-style: none">' + text + '</li>';
		} else {
			return '<li>' + text + '</li>';
		}
	};

	renderer.code = function (code, language) {
		code = code.replace(/</g, '&lt;').replace(/>/g, '&gt;');
		code = code.replace(/\r\n|\r|\n/g, '<br>');//???
		if (language == '' || language == undefined)
			return '<pre class="prettyprint">' + code + '</pre>';
		return '<pre class="prettyprint lang-' + language + '">' + code + '</pre>';
	};

	renderer.image = function (href, arg, title) {
		var path = getFilePath(href);
		return '<img src="' + path + '" title="' + title + '"/>';
	}

	Markdown.marked.setOptions({
		renderer: renderer,
		footnotes: true
	});
}

function Preview() {
	var doc = App.ActiveDoc;
	if (doc == null)
		doc = old_doc;
	if (doc == null)
		return;

	old_doc = doc;
	var dirty_id = doc.DirtyId;
	if (doc.id == old_id && dirty_id == old_dirty_id)
		return;

	if (doc.Syntax.toLowerCase() != "markdown")
		return;

	var rs = Markdown.marked(doc.Text);
	el_content.innerHTML = rs;

	var tocs = $("*[name='toc']");
	if (tocs.length) {
		var toc = generated_toc.generate('content');
		tocs.each(function () {
			$(this).html(toc);
		});
	}

	old_id = doc.id;
	old_dirty_id = dirty_id;
	prettyPrint();
}

InitMarked();

window.onload = function () {
	Preview();
	var instant_update = true;
	if (instant_update) {
		setInterval(Preview, 1000);
	}
}
