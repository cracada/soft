class ${1:MyClass}
{
	public static void main(String[] args) 
	{
		System.out.println("${0:Hello World!}");
	}
}
